var Engine = Matter.Engine,
    World = Matter.World,
    Events = Matter.Events,
    Bodies = Matter.Bodies;

    var particles =[];

function preload(){
    
}

function setup(){
   createCanvas(700,900);
   engine = Engine.create();
   world = engine.world;
   Engine.update(engine);

}

function draw(){
    background("black");

  if (frameCount% 60 === 0) { 
      particles.push (new rain (random (width / 230, width / 2 + 30), 10,10)); 
 } 
 
 for (var j = 0; j <particles.length; j ++) { 
      particles [j] .display ();     
}

}   

